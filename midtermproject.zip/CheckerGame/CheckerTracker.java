package edu.angelo.midtermprojectflenniken;

public class CheckerTracker {

    /**
     * The number of rows in the board
     */
    private final int numRows;
    /**
     * The number of columns in the board
     */
    private final int numColumns;

    /**
     * The array of all pieces in the board
     */
    private int[][] pieces;

    /**
     * No piece color
     */
    private final int empty = 0;
    /**
     * White checker color
     */
    private final int whiteColor = 1;
    /**
     * Red checker color
     */
    private final int redColor = 2;
    /**
     * White King Color
     */
    private final int whiteKing = 3;
    /**
     * Red King Color
     */
    private final int redKing = 4;
    /**
     * Color of choices
     */
    private final int choiceColor = 5;

    /**
     * Determines the color of the current player
     */
    private int playerColor;

    /**
     * Checks if the player can only jump
     */
    private boolean jumpOnly = false;
    /**
     * Checks if a piece has been selected
     */
    private boolean pieceSelected = false;

    /**
     * Sets the player row that is selected
     */
    private int playerRow;
    /**
     * Sets the player column that is selected
     */
    private int playerColumn;

    /**
     * Creates a checker board and initializes its elements to a standard checker game
     * Sets the current player color to red.
     * @param numRows The number of rows in the board
     * @param numColumns The number of columns in the board
     */
    public CheckerTracker(int numRows, int numColumns) {
        this.numRows = numRows;
        this.numColumns = numColumns;

        pieces = new int[numRows][numColumns];
        // WHITE
        for (int i = 0; i < 3; i += 1) {
            for (int j = 0; j < numColumns; j += 1) {
                if ((i + j) % 2 != 0) {
                    pieces[i][j] = whiteColor;
                }
            }
        }

        // EMPTY
        for (int i = 3; i < numRows - 3; i += 1) {
            for (int j = 0; j < numColumns; j += 1) {
                if ((i + j) % 2 != 0) {
                    pieces[i][j] = empty;
                }
            }
        }

        // RED
        for (int i = (numRows - 3); i < numRows; i += 1) {
            for (int j = 0; j < numColumns; j += 1) {
                if ((i + j) % 2 != 0) {
                    pieces[i][j] = redColor;
                }
            }
        }

        playerColor = redColor;
    }

    /**
     * Gets the current color value of the selected tile
     * @param row the row of the selected tile
     * @param column the column of the selected tile
     * @return the color value of the selected tile
     */
    public int getColor(int row, int column) {
        return pieces[row][column];
    }

    /**
     * Checks for a win state for red or white.
     * If no win state, determines who's turn it is.
     * @return the win state of the current game board
     */
    public int winState() {

        // 0: Red Turn
        // 1: White Turn
        // 2: Red Wins
        // 3: White Wins

        if (playerColor == whiteColor) {
            for (int i = 0; i < numRows; i += 1) {
                for (int j = 0; j < numColumns; j += 1) {
                    if ((i + j) % 2 != 0 && pieces[i][j] == choiceColor)
                        return 1;
                    if ((i + j) % 2 != 0 && isWhite(i, j)) {
                        if (hasMove(validMoves(i, j)))
                            return 1;
                    }
                }
            }
        }

        if (playerColor == redColor) {
            for (int i = 0; i < numRows; i += 1) {
                for (int j = 0; j < numColumns; j += 1) {
                    if ((i + j) % 2 != 0 && pieces[i][j] == choiceColor)
                        return 0;
                    if ((i + j) % 2 != 0 && isRed(i, j)) {
                        if (hasMove(validMoves(i, j)))
                            return 0;
                    }
                }
            }
        }

        if (playerColor == whiteColor)
            return 2;
        else if (playerColor == redColor)
            return 3;
        else
            return 0;
    }

    /**
     * Checks if the current player color has any valid moves
     * @param validMoves The array of possible moves for a specific tile
     * @return true if the player color has any valid moves, false if not
     */
    public boolean hasMove(int[][] validMoves) {
        for (int i = 0; i < numRows; i += 1) {
            for (int j = 0; j < numColumns; j += 1) {
                if ((i + j) % 2 != 0 && validMoves[i][j] != 0)
                    return true;
            }
        }
        return false;
    }

    /**
     * Checks if the selected piece can move or jump. Stores the values in an array.
     * @param row the row of the selected tile
     * @param column the column of the selected tile
     * @return an array of valid possible moves
     */
    public int[][] validMoves(int row, int column) {

        int[][] moves = new int[numRows][numColumns];

        if (isRed(row, column)) {

            try {
                if (isPiece(row - 1, column - 1) && isWhite(row - 1, column - 1) && pieces[row - 2][column - 2] == empty) {
                    moves[row - 2][column - 2] = 1;
                    jumpOnly = true;
                }
            } catch (ArrayIndexOutOfBoundsException e) { }
            try {
                if (isPiece(row - 1, column + 1) && isWhite(row - 1, column + 1) && pieces[row - 2][column + 2] == empty) {
                    moves[row - 2][column + 2] = 1;
                    jumpOnly = true;
                }
            } catch (ArrayIndexOutOfBoundsException e) { }

            if (isKing(row, column)) {

                try {
                    if (isPiece(row + 1, column - 1) && isWhite(row + 1, column - 1) && pieces[row + 2][column - 2] == empty) {
                        moves[row + 2][column - 2] = 1;
                        jumpOnly = true;
                    }
                } catch (ArrayIndexOutOfBoundsException e) { }
                try {
                    if (isPiece(row + 1, column + 1) && isWhite(row + 1, column + 1) && pieces[row + 2][column - 2] == empty) {
                        moves[row + 2][column + 2] = 1;
                        jumpOnly = true;
                    }
                } catch (ArrayIndexOutOfBoundsException e) { }

                if (jumpOnly)
                    return moves;

                try {
                    if (pieces[row + 1][column + 1] == empty)
                        moves[row + 1][column + 1] = 1;
                } catch (ArrayIndexOutOfBoundsException e) { }
                try {
                    if (pieces[row + 1][column - 1] == empty)
                        moves[row + 1][column - 1] = 1;
                } catch (ArrayIndexOutOfBoundsException e) { }
            }

            if (jumpOnly)
                return moves;

            try {
                if (pieces[row - 1][column + 1] == empty)
                    moves[row - 1][column + 1] = 1;
            } catch (ArrayIndexOutOfBoundsException e) { }
            try {
                if (pieces[row - 1][column - 1] == empty)
                    moves[row - 1][column - 1] = 1;
            } catch (ArrayIndexOutOfBoundsException e) { }
        }

        if (isWhite(row, column)) {

            try {
                if (isPiece(row + 1, column - 1) && isRed(row + 1, column - 1) && pieces[row + 2][column - 2] == empty) {
                    moves[row + 2][column - 2] = 1;
                    jumpOnly = true;
                }
            } catch (ArrayIndexOutOfBoundsException e) { }
            try {
                if (isPiece(row + 1, column + 1) && isRed(row + 1, column + 1) && pieces[row + 2][column + 2] == empty) {
                    moves[row + 2][column + 2] = 1;
                    jumpOnly = true;
                }
            } catch (ArrayIndexOutOfBoundsException e) { }

            if (isKing(row, column)) {
                try {
                    if (isPiece(row - 1, column - 1) && isRed(row - 1, column - 1) && pieces[row - 2][column - 2] == empty) {
                        moves[row - 2][column - 2] = 1;
                        jumpOnly = true;
                    }
                } catch (ArrayIndexOutOfBoundsException e) { }
                try {
                    if (isPiece(row - 1, column + 1) && isRed(row - 1, column + 1) && pieces[row - 2][column + 2] == empty) {
                        moves[row - 2][column + 2] = 1;
                        jumpOnly = true;
                    }
                } catch (ArrayIndexOutOfBoundsException e) { }
                if (jumpOnly = true)
                    return moves;

                try {
                    if (pieces[row - 1][column - 1] == empty)
                        moves[row - 1][column - 1] = 1;
                } catch (ArrayIndexOutOfBoundsException e) { }
                try {
                    if (pieces[row - 1][column + 1] == empty)
                        moves[row - 1][column + 1] = 1;
                } catch (ArrayIndexOutOfBoundsException e) { }
            }
            if (jumpOnly == true)
                return moves;

            try {
                if (pieces[row + 1][column - 1] == empty)
                    moves[row + 1][column - 1] = 1;
            } catch (ArrayIndexOutOfBoundsException e) { }
            try {
                if (pieces[row + 1][column + 1] == empty) moves[row + 1][column + 1] = 1;
            } catch (ArrayIndexOutOfBoundsException e) { }
        }

        return moves;
    }

    /**
     * Clicks a tile and displays moves if any.
     * If a choice tile is clicked, determines if the piece should move or jump and executes the correct choice.
     * @param row the row of the selected tile
     * @param column the column of the selected tile
     */
    public void click(int row, int column) {

        if (isRed(row, column) && playerColor == redColor) {
            if (!pieceSelected) {
                pieceSelected = true;
                playerRow = row;
                playerColumn = column;
                int[][] choices = validMoves(row, column);
                displayMoves(choices);
            }
            else {
                pieceSelected = false;
                resetChoices();
            }
        }

        if (isWhite(row, column) && playerColor == whiteColor) {
            if (!pieceSelected) {
                pieceSelected = true;
                playerRow = row;
                playerColumn = column;
                int[][] choices = validMoves(row, column);
                displayMoves(choices);
            }
            else {
                pieceSelected = false;
                resetChoices();
            }
        }

        if (getColor(row, column) == choiceColor && pieceSelected) {
            if (jumpOnly) {
                pieceSelected = false;
                jump(playerRow, playerColumn, row, column);
            }
            else {
                pieceSelected = false;
                move(playerRow, playerColumn, row, column);
            }
        }
    }

    /**
     * Displays all possible choices that a piece can take
     * @param choices the array of choices that a piece has
     */
    public void displayMoves(int[][] choices) {
        for (int i = 0; i < numRows; i += 1) {
            for (int j = 0; j < numColumns; j += 1) {
                if ((i + j) % 2 != 0 && choices[i][j] != 0) {
                    pieces[i][j] = choiceColor;
                }
            }
        }
    }

    /**
     * Removes any choice tiles remaining on the board
     */
    public void resetChoices() {
        for (int i = 0; i < numRows; i += 1) {
            for (int j = 0; j < numColumns; j += 1) {
                if ((i + j) % 2 != 0 && pieces[i][j] == choiceColor) {
                    pieces[i][j] = empty;
                }
            }
        }
    }

    /**
     * Moves the tile to the specified location
     * @param playerRow the row of the player's piece
     * @param playerColumn the column of the player's piece
     * @param tileRow the row of the selected end tile
     * @param tileColumn the column of the selected end tile
     */
    public void move(int playerRow, int playerColumn, int tileRow, int tileColumn) {
        pieces[tileRow][tileColumn] = pieces[playerRow][playerColumn];
        pieces[playerRow][playerColumn] = empty;

        if (playerColor == redColor) {
            if (tileRow == 0)
                pieces[tileRow][tileColumn] = redKing;
        }
        else if (playerColor == whiteColor) {
            if (tileRow == numRows - 1)
                pieces[tileRow][tileColumn] = whiteKing;
        }

        resetChoices();

        if (playerColor == redColor)
            playerColor = whiteColor;
        else if (playerColor == whiteColor)
            playerColor = redColor;
    }

    /**
     * Jumps the player's tile over an opponent's tile
     * @param playerRow the row of the player's piece
     * @param playerColumn the column of the player's piece
     * @param choiceRow the row of the selected end tile
     * @param choiceColumn the column of the selected end tile
     */
    public void jump(int playerRow, int playerColumn, int choiceRow, int choiceColumn) {
        if (playerRow > choiceRow) {
            if (playerColumn > choiceColumn) {
                pieces[playerRow - 1][playerColumn - 1] = empty;
            }
            else
                pieces[playerRow - 1][playerColumn + 1] = empty;
        }
        else {
            if (playerColumn > choiceColumn)
                pieces[playerRow + 1][playerColumn - 1] = empty;
            else
                pieces[playerRow + 1][playerColumn + 1] = empty;
        }

        pieces[choiceRow][choiceColumn] = pieces[playerRow][playerColumn];
        pieces[playerRow][playerColumn] = empty;

        jumpOnly = false;

        if (playerColor == redColor) {
            if (choiceRow == 0)
                pieces[choiceRow][choiceColumn] = redKing;
        }
        else if (playerColor == whiteColor) {
            if (choiceRow == numRows - 1)
                pieces[choiceRow][choiceColumn] = whiteKing;
        }

        resetChoices();

        int[][] jumpCheck = validMoves(choiceRow, choiceColumn);
        if (jumpOnly && hasMove(jumpCheck)) {
            click(choiceRow, choiceColumn);
            displayMoves(jumpCheck);
            return;
        }

        if (playerColor == redColor)
            playerColor = whiteColor;
        else
            playerColor = redColor;
    }

    /**
     * Returns a string value of what player is currently playing
     * @return the string value of what player is playing
     */
    public String playerColor() {
        if (playerColor == 2)
            return "red";
        else
            return "white";
    }

    /**
     * Checks if the selected tile is a checker piece
     * @param row the row of the selected tile
     * @param column the column of the selected tile
     * @return true if the tile is a checker piece, false if not
     */
    public boolean isPiece(int row, int column) {
        if (pieces[row][column] != 0 && pieces[row][column] != 5)
            return true;
        return false;
    }

    /**
     * Checks if the piece is red
     * @param row the row of the selected tile
     * @param column the column of the selected tile
     * @return true if the piece is red, false if not
     */
    public boolean isRed(int row, int column) {
        if (pieces[row][column] == 2 || pieces[row][column] == 4)
            return true;
        return false;
    }

    /**
     * Checks if the piece is white
     * @param row the row of the selected tile
     * @param column the column of the selected tile
     * @return true if the piece is white, false if not
     */
    public boolean isWhite(int row, int column) {
        if (pieces[row][column] == 1 || pieces[row][column] == 3)
            return true;
        return false;
    }

    /**
     * Checks if the piece is a king
     * @param row the row of the selected tile
     * @param column the column of the selected tile
     * @return true if the piece is a king, false if not
     */
    public boolean isKing(int row, int column) {
        if (pieces[row][column] == 3 || pieces[row][column] == 4)
            return true;
        return false;
    }

    /**
     * Tests a few functions of the CheckerTracker class
     * @param args args in not used in this code.
     */
    public static void main(String args[]) {
        CheckerTracker tracker = new CheckerTracker(8, 8);
        System.out.println("Player turn: " + tracker.playerColor());
        tracker.click(0, 1);
        System.out.print("Choice 1,0: ");
        if (tracker.getColor(1,0) == 5)
            System.out.println("true");
        else
            System.out.println("false");

        tracker.click(0, 1);

        tracker.click(5, 0);
        System.out.println(tracker.getColor(4, 1));
        System.out.print("Choice 4, 1: ");
        if (tracker.getColor(4,1) == 5)
            System.out.println("true");
        else
            System.out.println("false");

        tracker.click(5, 0);
        System.out.println(tracker.getColor(4, 1));
        System.out.print("Choice 4, 1: ");
        if (tracker.getColor(4,1) == 5)
            System.out.println("true");
        else
            System.out.println("false");

        tracker.click(5, 0);
        tracker.click(4, 1);
        System.out.println("(5, 0): " + tracker.getColor(5, 0));
        System.out.println("(4, 1): " + tracker.getColor(4, 1));
        System.out.println("Player turn: " + tracker.playerColor());

        tracker.click(2, 1);
        tracker.click(3, 2);
        System.out.println("(2, 1): " + tracker.getColor(2, 1));
        System.out.println("(3, 2): " + tracker.getColor(3, 2));
        System.out.println("Player turn: " + tracker.playerColor());

        tracker.click(5, 2);
        tracker.click(4, 3);
        System.out.println("(5, 2): " + tracker.getColor(5, 2));
        System.out.println("(4, 3): " + tracker.getColor(4, 3));
        System.out.println("Player turn: " + tracker.playerColor());

        tracker.click(3, 2);
        tracker.click(5, 0);
        System.out.println("(3, 2): " + tracker.getColor(3, 2));
        System.out.println("(5, 0): " + tracker.getColor(5, 0));
        System.out.println("Player turn: " + tracker.playerColor());

    }
}