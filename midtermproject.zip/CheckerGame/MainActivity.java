package edu.angelo.midtermprojectflenniken;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    private CheckerTracker tracker;

    private ImageView[][] checkers;

    private final int NUM_ROWS = 8;
    private final int NUM_COLUMNS = 8;

    private static final String TAG = "PlayerColor";

    private boolean jumpOnly = false;

    private void updateBoard() {
        for (int i = 0; i < NUM_ROWS; i += 1) {
            for (int j = 0; j < NUM_COLUMNS; j += 1) {
                if ((i + j) % 2 != 0) {
                    try {
                        switch (tracker.getColor(i, j)) {
                            case 0:
                                checkers[i][j].setImageResource(R.drawable.clear);
                                break;
                            case 1:
                                checkers[i][j].setImageResource(R.drawable.whitechecker);
                                break;
                            case 2:
                                checkers[i][j].setImageResource(R.drawable.redchecker);
                                break;
                            case 3:
                                checkers[i][j].setImageResource(R.drawable.whitekingchecker);
                                break;
                            case 4:
                                checkers[i][j].setImageResource(R.drawable.redkingchecker);
                                break;
                            case 5:
                                checkers[i][j].setImageResource(R.drawable.choice);
                                break;
                        }
                    } catch (ArrayIndexOutOfBoundsException e) {}
                }
            }
        }

        Log.i(TAG, "Player Color: " + tracker.playerColor());

        /*if (!jumpOnly) {
            if (tracker.hasJump()) {
                jumpOnly = true;
                updateBoard();
                return;
            }
        }

        jumpOnly = false;*/

        final TextView textView = findViewById(R.id.textView);

        switch (tracker.winState()) {
            case 0:
                textView.setBackgroundColor(Color.rgb(240, 220, 130));
                textView.setTextColor(Color.RED);
                textView.setText("RED'S TURN");
                break;
            case 1:
                textView.setBackgroundColor(Color.rgb(65, 146, 75));
                textView.setTextColor(Color.WHITE);
                textView.setText("WHITE'S TURN");
                break;
            case 2:
                textView.setBackgroundColor(Color.RED);
                textView.setTextColor(Color.WHITE);
                textView.setText("RED WINS!!");
                break;
            case 3:
                textView.setBackgroundColor(Color.WHITE);
                textView.setTextColor(Color.BLACK);
                textView.setText("WHITE WINS!!");
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       tracker = new CheckerTracker(NUM_ROWS, NUM_COLUMNS);

       checkers = new ImageView[][]{{
                findViewById(R.id.tile00),
                findViewById(R.id.tile01),
                findViewById(R.id.tile02),
                findViewById(R.id.tile03),
                findViewById(R.id.tile04),
                findViewById(R.id.tile05),
                findViewById(R.id.tile06),
                findViewById(R.id.tile07),
        }, {
                findViewById(R.id.tile10),
                findViewById(R.id.tile11),
                findViewById(R.id.tile12),
                findViewById(R.id.tile13),
                findViewById(R.id.tile14),
                findViewById(R.id.tile15),
                findViewById(R.id.tile16),
                findViewById(R.id.tile17),
        }, {
                findViewById(R.id.tile20),
                findViewById(R.id.tile21),
                findViewById(R.id.tile22),
                findViewById(R.id.tile23),
                findViewById(R.id.tile24),
                findViewById(R.id.tile25),
                findViewById(R.id.tile26),
                findViewById(R.id.tile27),
        }, {
                findViewById(R.id.tile30),
                findViewById(R.id.tile31),
                findViewById(R.id.tile32),
                findViewById(R.id.tile33),
                findViewById(R.id.tile34),
                findViewById(R.id.tile35),
                findViewById(R.id.tile36),
                findViewById(R.id.tile37),
        }, {
                findViewById(R.id.tile40),
                findViewById(R.id.tile41),
                findViewById(R.id.tile42),
                findViewById(R.id.tile43),
                findViewById(R.id.tile44),
                findViewById(R.id.tile45),
                findViewById(R.id.tile46),
                findViewById(R.id.tile47),
        }, {
                findViewById(R.id.tile50),
                findViewById(R.id.tile51),
                findViewById(R.id.tile52),
                findViewById(R.id.tile53),
                findViewById(R.id.tile54),
                findViewById(R.id.tile55),
                findViewById(R.id.tile56),
                findViewById(R.id.tile57),
        }, {
                findViewById(R.id.tile60),
                findViewById(R.id.tile61),
                findViewById(R.id.tile62),
                findViewById(R.id.tile63),
                findViewById(R.id.tile64),
                findViewById(R.id.tile65),
                findViewById(R.id.tile66),
                findViewById(R.id.tile67),
        }, {
                findViewById(R.id.tile70),
                findViewById(R.id.tile71),
                findViewById(R.id.tile72),
                findViewById(R.id.tile73),
                findViewById(R.id.tile74),
                findViewById(R.id.tile75),
                findViewById(R.id.tile76),
                findViewById(R.id.tile77),
        }};

       updateBoard();
    }

    public void click01(View view) {
        tracker.click(0, 1);
        updateBoard();
    }

    public void click03(View view) {
        tracker.click(0, 3);
        updateBoard();
    }

    public void click05(View view) {
        tracker.click(0, 5);
        updateBoard();
    }

    public void click07(View view) {
        tracker.click(0, 7);
        updateBoard();
    }

    public void click10(View view) {
        tracker.click(1, 0);
        updateBoard();
    }

    public void click12(View view) {
        tracker.click(1, 2);
        updateBoard();
    }

    public void click14(View view) {
        tracker.click(1, 4);
        updateBoard();
    }

    public void click16(View view) {
        tracker.click(1, 6);
        updateBoard();
    }

    public void click21(View view) {
        tracker.click(2, 1);
        updateBoard();
    }

    public void click23(View view) {
        tracker.click(2, 3);
        updateBoard();
    }

    public void click25(View view) {
        tracker.click(2, 5);
        updateBoard();
    }

    public void click27(View view) {
        tracker.click(2, 7);
        updateBoard();
    }

    public void click30(View view) {
        tracker.click(3, 0);
        updateBoard();
    }

    public void click32(View view) {
        tracker.click(3, 2);
        updateBoard();
    }

    public void click34(View view) {
        tracker.click(3, 4);
        updateBoard();
    }

    public void click36(View view) {
        tracker.click(3, 6);
        updateBoard();
    }

    public void click41(View view) {
        tracker.click(4, 1);
        updateBoard();
    }

    public void click43(View view) {
        tracker.click(4, 3);
        updateBoard();
    }

    public void click45(View view) {
        tracker.click(4, 5);
        updateBoard();
    }

    public void click47(View view) {
        tracker.click(4, 7);
        updateBoard();
    }

    public void click50(View view) {
        tracker.click(5, 0);
        updateBoard();
    }

    public void click52(View view) {
        tracker.click(5, 2);
        updateBoard();
    }

    public void click54(View view) {
        tracker.click(5, 4);
        updateBoard();
    }

    public void click56(View view) {
        tracker.click(5, 6);
        updateBoard();
    }

    public void click61(View view) {
        tracker.click(6, 1);
        updateBoard();
    }

    public void click63(View view) {
        tracker.click(6, 3);
        updateBoard();
    }

    public void click65(View view) {
        tracker.click(6, 5);
        updateBoard();
    }

    public void click67(View view) {
        tracker.click(6, 7);
        updateBoard();
    }

    public void click70(View view) {
        tracker.click(7, 0);
        updateBoard();
    }

    public void click72(View view) {
        tracker.click(7, 2);
        updateBoard();
    }

    public void click74(View view) {
        tracker.click(7, 4);
        updateBoard();
    }

    public void click76(View view) {
        tracker.click(7, 6);
        updateBoard();
    }

    public void startNewGame(View view) {
        tracker = new CheckerTracker(NUM_ROWS, NUM_COLUMNS);
        updateBoard();
    }
}
