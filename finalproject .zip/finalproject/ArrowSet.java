package edu.angelo.finalprojectflenniken;

import java.util.ArrayList;
import java.util.List;

public class ArrowSet {

    /**
     * A list of all notes of the song
     */
    public int[] track = {3, 2, 2, 0, 3, 2, 2, 0, // 8
                          1, 0, 2, 0, 0, 3, 0, 2, 0, 0, // 10
                          3, 3, 3, 1, 0, 1, 0, 3, 2, 1, 3, // 11
                          3, 3, 3, 1, 0, 1, 0, 3, 2, 1, 1, // 11
                          0, 1, 2, 3, 2, 1, 2, 0, 1, 2, 3, 2, 1, 2, // 14
                          3, 2, 2, 0, 3, 0, 1, 3, 2, 1, 0, // 11
                          0, 1, 2, 3, 2, 1, 2, 0, 1, 2, 3, 2, 1, 2, // 14
                          1, 0, 2, 0, 0, 3, 0, 2, 0, 0, // 10
                          3, 3, 3, 1, 0, 1, 0, 3, 2, 1, 3, // 11
                          3, 3, 3, 1, 0, 1, 0, 3, 2, 1, 1, // 11
                          0, 1, 2, 3, 2, 1, 2, 0, 1, 2, 3, 2, 1, 2, // 14
                          1, 0, 2, 0, 0, 3, 0, 2, 0, 0, // 10
                          2, 2, 1, 2, 3, 0, 2, 1, 1, 0, 1, // 11
                          0, 2, 2, 2, 1, 2, 3, 2, // 8
                          2, 2, 1, 2, 3, 0, 2, 1, 1, 0, 1, // 11
                          0, 0, 1, 2, 2, 1, 1, 2, 3, 2, 3, 2, // 12
                          3, 3, 2, 0, 3, 3, 2, 0, // 8
                          3, 3, 3, 2, 0, 0, 1, 2, 3, 2, 1, 0, // 12
                          0, 3, 2, 2, 1, 0 }; // 6

    /**
     * A list of all the times in-between the notes to get the correct spacing
     */
    public int[] waitTimes = {4, 8, 12, 16, 20, 24, 28, 32,
                              36, 40, 42, 44, 48, 52, 56, 58, 60, 64,
                              72, 74, 76, 78, 80, 82, 86, 88, 90, 94, 96,
                              104, 106, 108, 110, 112, 114, 118, 120, 122, 126, 128,
                              132, 134, 136, 138, 142, 144, 146, 148, 150, 152, 154, 158, 160, 162,
                              164, 168, 172, 176, 180, 182, 184, 186, 190, 192, 194,
                              196, 198, 200, 202, 206, 208, 210, 212, 214, 216, 218, 222, 224, 226,
                              228, 232, 234, 236, 240, 244, 248, 250, 252, 256,
                              264, 266, 268, 270, 272, 274, 278, 280, 282, 286, 288,
                              296, 298, 300, 302, 304, 306, 310, 312, 314, 318, 320,
                              324, 326, 328, 330, 334, 336, 338, 340, 342, 344, 346, 350, 352, 354,
                              356, 360, 362, 364, 368, 372, 376, 378, 380, 384,
                              390, 396, 397, 398, 400, 404, 406, 408, 410, 411, 412,
                              420, 422, 424, 428, 429, 530, 432, 436,
                              452, 458, 459, 460, 462, 466, 468, 470, 472, 473, 474,
                              486, 490, 492, 494, 500, 504, 508, 510, 512, 514, 516, 518,
                              522, 524, 526, 528, 534, 536, 540, 544,
                              552, 554, 556, 558, 560, 562, 566, 568, 572, 576, 580, 582,
                              600, 602, 606, 608, 610, 614};


    /**
     * A variable to keep track of the final wait time
     */
    int totalWaitTime = waitTimes[waitTimes.length - 1];

    /**
     * Creates a list of all arrows in the scene
     */
    public List<Arrows> arrows;

    /**
     * A constructor that sets and fills the arrows in the world
     * @param numArrows the total number of arrows in the song
     */
    public ArrowSet(int numArrows) {

        // make the list into an arrayList
        arrows = new ArrayList<Arrows>();

        // Loop through each element in the arrayList
        // and set it's arrowType, location, and maxY
        int i = 0;
        while (arrows.size() < numArrows) {
            arrows.add(new Arrows());
            arrows.get(i).arrowType = track[i];
            arrows.get(i).locationY = waitTimes[i] - 40 - (16*waitTimes[i]);
            arrows.get(i).maxY = World.WORLD_HEIGHT + (16*totalWaitTime);
            i += 1;
        }
    }

    /**
     * A default constructor that calls the other constructor
     * with the correct number of arrows
     */
    public ArrowSet() { this(203);}

    /**
     * Calls the advance function for each arrow in the scene
     */
    public void advance() {

        // This uses an enhanced loop syntax style in order to improve efficiency.
        // Instead of relying on a classic for loop, this one uses a for-each loop
        for (Arrows arrow : arrows) {
            arrow.advance();
        }
    }
}
