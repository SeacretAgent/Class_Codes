package edu.angelo.finalprojectflenniken;

public class Arrows {

    /**
     * variables that keep track of the x positions of each arrow
     */
    public static final int leftX = (World.WORLD_WIDTH / 2) - 108;
    public static final int downX = (World.WORLD_WIDTH / 2) - 36;
    public static final int upX = (World.WORLD_WIDTH / 2) + 36;
    public static final int rightX = (World.WORLD_WIDTH / 2) + 108;

    /**
     * Keeps track of the bottom of the world to check for intersections
     */
    public int maxY = World.WORLD_HEIGHT + 16;

    /**
     * Determines if the current arrow is a left, right, down, up, or clear arrow
     */
    public int arrowType = 0;

    /**
     * keeps track of the old arrow type in order to reset arrows after they are off the screen
     */
    public int oldArrowType = 0;

    /**
     * The player has 3 misses before the game fails them
     * the hit function is to make sure each arrow only intersects once
     */
    public static int numLives = 3;
    public boolean hit = false;

    /**
     * Keeps track of the X coordinate of the center of the arrow.
     */
    public int locationX;

    /**
     * Keeps track of the y coordinate of the center of the arrow.
     */
    public int locationY;

    /**
     * Keeps track of the y velocity of the center of the arrow.
     */
    public static final int velocityY = 1;

    /**
     * Moves the arrows down the screen in their respective x locations and checks if they can be recycled
     */
    public void advance() {

        // If arrow is left, put it in the left column
        if (arrowType == 0) {
            oldArrowType = 0;
            locationX = leftX;
        }
        // If arrow is down, put it in the down column
        else if (arrowType == 1) {
            oldArrowType = 1;
            locationX = downX;
        }
        // If arrow is up, put it in the up column
        else if (arrowType == 2) {
            oldArrowType = 2;
            locationX = upX;
        }
        // If arrow is right, put it in the right column
        else if (arrowType == 3) {
            oldArrowType = 3;
            locationX = rightX;
        }

        // Calculate the new location y as it moves down
        int newLocationY = locationY + velocityY;

        // Check if the now location is further than the world height and is not clear yet
        if (newLocationY > World.WORLD_HEIGHT && arrowType != 4 && !hit) {
            // Decrease number of lives left and make sure the arrow doesn't decrease
            // numLives more than once
            numLives--;
            hit = true;
        }

        // If the newLocationY is psat the maximumY, meaning the song has ended, then place it back at the top.
        if (newLocationY > maxY) {
            locationY = -16;
            arrowType = oldArrowType;
        }
        // Else, just update the location to the newLocationY
        else
            locationY = newLocationY;
    }
}
