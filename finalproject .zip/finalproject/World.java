package edu.angelo.finalprojectflenniken;

import android.os.Debug;
import android.util.Log;
import android.view.MotionEvent;

import java.lang.Math;


/**
 * From The Art of Game Design: A Book of Lenses,
 * my game makes use of the design mechanic related to Objects and their attributes and states.
 * My game's arrows are placed in a way and specific order that gradually gets more difficult and complex
 * as the song progresses. I did this by making sure to try and variate the pattern in the arrows so that
 * the player does not stick to just one or two arrows only. This way, the player has to continue learning
 * and bettering their skills in order to get a better or even perfect score. These objects, my arrows, and how
 * they are ordered in relation to the song and to each other, creates a game loop that intrigues the player to
 * beat the game with the best score as possible.
 */

public class World {
    public static final int WORLD_WIDTH = 320;
    public static final int WORLD_HEIGHT = 480;
    static final int MAX_SCORE = 10;
    static final int SCORE_DECREMENT = 10;
    static final float TICK_INITIAL = 0.0085f;


    public ArrowSet arrowSet;
    public boolean gameOver = false;
    public int score = 0;
    float tickTime = 0;
    float tick = TICK_INITIAL;

    /**
     * Boolean to check if the player clicked to start the game.
     */
    public boolean hasClicked = false;

    /**
     * Creates a ArrowSet object of the arrows in the world.
     */
    public World() { arrowSet = new ArrowSet(); }

    /**
     * Updates the board by the tick speed and checks if the game has ended to stop updating the time
     * Also checks to see if the player has run out of lives and ends the game if they have.
     * @param deltaTime A parameter to make sure the game runs at the same speed on any device
     */
    public void update(float deltaTime) {
        if (Arrows.numLives == 0)
            gameOver = true;

        if (gameOver) {
            return;
        }

        tickTime += deltaTime;

        while (tickTime > tick) {
            tickTime -= tick;
            arrowSet.advance();
        }
    }

    /**
     * Checks whether the player hits an arrow in a specified range of the arrow container at the bottom.
     * If not, the player will lose 10 points unless they are below 10, in which their score will be set to 0.
     * @param x The x coordinate of the player's click
     * @param y The y coordinate of the player's click
     */
    public void shoot(int x, int y) {

        // A variable that keeps track of the current closest arrow to the player
        int closestArrow = 0;

        // Variables to see if any arrow has been hit in order to not decrement points
        boolean arrowHit = false;
        boolean clicked = false;

        // An array of distances from the clicked location to the incoming arrows
        float distances[] = new float[arrowSet.arrows.size()];
        // Sets the distances to a very high number to make sure they won't be used until later.
        for (int i = 0; i < distances.length; i += 1) {
            distances[i] = 12345678f;
        }

        // If you have clicked the screen at least once
        if (hasClicked) {
            // Check to see if the player has clicked on a specific arrow
            if (x > 0 && x < (WORLD_WIDTH / 2) - 72 && y < WORLD_HEIGHT && y > WORLD_HEIGHT - 100) {
                clicked = true;
                for (int i = 0; i < arrowSet.arrows.size(); i += 1) {
                    if (arrowSet.arrows.get(i).arrowType == 0) {
                        // Get the distance from the arrow and the clicked arrow location
                        distances[i] = Math.abs(arrowSet.arrows.get(i).locationY - (WORLD_HEIGHT - 67));
                        closestArrow = i;
                    }
                }
            }
            if (x > (WORLD_WIDTH / 2) - 72 && x < WORLD_WIDTH / 2 && y < WORLD_HEIGHT && y > WORLD_HEIGHT - 100) {
                clicked = true;
                for (int i = 0; i < arrowSet.arrows.size(); i += 1) {
                    if (arrowSet.arrows.get(i).arrowType == 1) {
                        // Get the distance from the arrow and the clicked arrow location
                        distances[i] = Math.abs(arrowSet.arrows.get(i).locationY - (WORLD_HEIGHT - 67));
                        closestArrow = i;
                    }
                }
            }
            if (x > WORLD_WIDTH / 2 && x < (WORLD_WIDTH / 2) + 72 && y < WORLD_HEIGHT && y > WORLD_HEIGHT - 100) {
                clicked = true;
                for (int i = 0; i < arrowSet.arrows.size(); i += 1) {
                    if (arrowSet.arrows.get(i).arrowType == 2) {
                        // Get the distance from the arrow and the clicked arrow location
                        distances[i] = Math.abs(arrowSet.arrows.get(i).locationY - (WORLD_HEIGHT - 67));
                        closestArrow = i;
                    }
                }
            }
            if (x > (WORLD_WIDTH / 2) + 72 && x < WORLD_WIDTH && y < WORLD_HEIGHT && y > WORLD_HEIGHT - 100) {
                clicked = true;
                for (int i = 0; i < arrowSet.arrows.size(); i += 1) {
                    if (arrowSet.arrows.get(i).arrowType == 3) {
                        // Get the distance from the arrow and the clicked arrow location
                        distances[i] = Math.abs(arrowSet.arrows.get(i).locationY - (WORLD_HEIGHT - 67));
                        closestArrow = i;
                    }
                }
            }

            // If you clicked and there is an arrow within 100 units away,
            // then find the closest arrow and set it as the current arrow
            if (clicked) {
                for (int i = 0; i < distances.length - 1; i += 1) {
                    if (distances[i] <= 100) {
                        closestArrow = i;
                        arrowHit = true;
                        break;
                    }
                }

                // If no arrows were hit, decrement the score.
                if (!arrowHit) {
                    if (score >= 10)
                        score -= SCORE_DECREMENT;
                    else
                        score = 0;
                }

                // If there is an arrow withing 100 units, then set it to the clear arrow and calculate the score.
                if (distances[closestArrow] <= 100) {
                    arrowSet.arrows.get(closestArrow).arrowType = 4;
                    // if you clicked within 16 units, you get the max score.
                    if (distances[closestArrow] <= 16)
                        score += MAX_SCORE;
                    else
                        score += (100 - distances[closestArrow]) / 10;
                }
            }
        }
        // Set hasClicked to true after the first click to make sure that
        //  the player can click without causing a game over.
        hasClicked = true;
    }
}
