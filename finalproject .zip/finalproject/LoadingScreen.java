package edu.angelo.finalprojectflenniken;

import com.badlogic.androidgames.framework.Game;
import com.badlogic.androidgames.framework.Graphics;
import com.badlogic.androidgames.framework.Screen;
import com.badlogic.androidgames.framework.Graphics.PixmapFormat;

public class LoadingScreen extends Screen {
    public LoadingScreen(Game game) {
        super(game);
    }

    public void update(float deltaTime) {
        Graphics g = game.getGraphics();
        Assets.background = g.newPixmap("background.png", PixmapFormat.ARGB8888);

        Assets.logo = g.newPixmap("rhythmFever.png", PixmapFormat.ARGB8888);
        Assets.credits1 = g.newPixmap("credits1.png", PixmapFormat.ARGB8888);

        Assets.mainMenu = g.newPixmap("mainmenu.png", PixmapFormat.ARGB8888);
        Assets.buttons = g.newPixmap("buttons.png", PixmapFormat.ARGB8888);
        Assets.help1 = g.newPixmap("help1.png", PixmapFormat.ARGB8888);
        Assets.help2 = g.newPixmap("help2.png", PixmapFormat.ARGB8888);
        Assets.help3 = g.newPixmap("help3.png", PixmapFormat.ARGB8888);
        Assets.numbers = g.newPixmap("numbers.png", PixmapFormat.ARGB8888);
        Assets.ready = g.newPixmap("ready.png", PixmapFormat.ARGB8888);
        Assets.pause = g.newPixmap("pausemenu.png", PixmapFormat.ARGB8888);
        Assets.gameOver = g.newPixmap("gameover.png", PixmapFormat.ARGB8888);
        Assets.headUp = g.newPixmap("headup.png", PixmapFormat.ARGB8888);
        Assets.headLeft = g.newPixmap("headleft.png", PixmapFormat.ARGB8888);
        Assets.headDown = g.newPixmap("headdown.png", PixmapFormat.ARGB8888);
        Assets.headRight = g.newPixmap("headright.png", PixmapFormat.ARGB8888);
        Assets.tail = g.newPixmap("tail.png", PixmapFormat.ARGB8888);
        Assets.stain1 = g.newPixmap("stain1.png", PixmapFormat.ARGB8888);
        Assets.stain2 = g.newPixmap("stain2.png", PixmapFormat.ARGB8888);
        Assets.stain3 = g.newPixmap("stain3.png", PixmapFormat.ARGB8888);
        Assets.target = g.newPixmap("target.png", PixmapFormat.ARGB8888);
        Assets.target2 = g.newPixmap("target2.png", PixmapFormat.ARGB8888);

        Assets.arrowLeft = g.newPixmap("arrowLeft.png", PixmapFormat.ARGB8888);
        Assets.arrowDown = g.newPixmap("arrowDown.png", PixmapFormat.ARGB8888);
        Assets.arrowUp = g.newPixmap("arrowUp.png", PixmapFormat.ARGB8888);
        Assets.arrowRight = g.newPixmap("arrowRight.png", PixmapFormat.ARGB8888);
        Assets.disappear = g.newPixmap("disappear.png", PixmapFormat.ARGB8888);

        Assets.arrowTargetLeft = g.newPixmap("arrowTargetLeft.png", PixmapFormat.ARGB8888);
        Assets.arrowTargetDown = g.newPixmap("arrowTargetDown.png", PixmapFormat.ARGB8888);
        Assets.arrowTargetUp = g.newPixmap("arrowTargetUp.png", PixmapFormat.ARGB8888);
        Assets.arrowTargetRight = g.newPixmap("arrowTargetRight.png", PixmapFormat.ARGB8888);

        Assets.click = game.getAudio().newSound("click.ogg");
        Assets.eat = game.getAudio().newSound("eat.ogg");
        Assets.bitten = game.getAudio().newSound("gameover.ogg");
        Assets.paused = game.getAudio().newSound("paused.ogg");

        Assets.music = game.getAudio().newMusic("billieJean.ogg");

        Assets.music.setLooping(true);
        Settings.load(game.getFileIO());
        game.setScreen(new MainMenuScreen(game));
    }

    public void present(float deltaTime) {
    }

    public void pause() {
    }

    public void resume() {
    }

    public void dispose() {
    }
}
